﻿using Microsoft.AspNetCore.Identity;
using Samurai.Application.Security.Contracts;
using Samurai.Interface.Security.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Samurai.Interface.Security.Manager
{
    public class SignInManager : ISignInManager<MyUser>
    {
        public Task<SignInResult> PasswordSignInAsync
            (string userName, string password, bool isPersistent,
            bool lockoutOnFailure)
        {
            if (password == "12345")
            {
                return Task.FromResult(SignInResult.Success);
            }
            else
            {
                return Task.FromResult(SignInResult.Failed);
            }

        }
    }
}
