﻿using Microsoft.AspNetCore.Mvc;
using Samurai.Application.Contracts;
using Samurai.Domain;

namespace Samurai.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SamuraiController : Controller
    {
        private readonly ISamuraiWarriorRepository _warriorRepository;

        public SamuraiController(ISamuraiWarriorRepository warriorRepository)
        {
            _warriorRepository = warriorRepository;
        }
        [HttpGet(Name ="GetAllSamurais")]
        public async Task<ActionResult<List<Warrior>>> GetAllSamurais()
        {
            var list = await _warriorRepository.GetAllAsync();
            return list;
        }
    }
}
