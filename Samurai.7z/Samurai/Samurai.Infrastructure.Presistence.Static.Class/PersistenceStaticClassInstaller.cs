﻿using Microsoft.Extensions.DependencyInjection;
using Samurai.Application.Contracts;
using Samurai.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Samurai.Infrastructure.Presistence.Static.Class
{
    public static class PersistenceStaticClassInstaller
    {
        public static IServiceCollection AddPersistenceServices
            (this IServiceCollection services)
        {

            services.AddScoped<ISamuraiWarriorRepository, SamuraiWarriorRepository>();

            return services;
        }
    }
}
