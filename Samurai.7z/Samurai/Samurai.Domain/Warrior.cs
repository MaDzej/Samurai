﻿namespace Samurai.Domain
{
    public class Warrior
    {
        public string Name { get; set; }
        public string ImageUrl { get; set; }
        public int Age { get; set; }

    }
}