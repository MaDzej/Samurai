﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Samurai.Application.Security.Models
{
    public class RegistrationResponse
    {
        public string UserId { get; set; }
    }
}
